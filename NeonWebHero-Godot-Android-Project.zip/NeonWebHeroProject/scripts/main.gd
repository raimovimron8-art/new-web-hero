extends Node3D

const CITY_RADIUS := 6
const BLOCK_SIZE := 18.0
const STREET_WIDTH := 7.0
var player: CharacterBody3D
var camera_pivot: Node3D
var camera: Camera3D
var rope: MeshInstance3D
var anchor: Vector3 = Vector3.ZERO
var swinging := false
var look_drag := false
var last_touch := Vector2.ZERO
var yaw := 0.0
var pitch := -0.18
var status_label: Label
var touch_ui: CanvasLayer

func _ready() -> void:
	_setup_environment()
	_build_city()
	_create_player()
	_create_ui()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _setup_environment() -> void:
	var world := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.015, 0.025, 0.12)
	sky_mat.sky_horizon_color = Color(0.08, 0.025, 0.18)
	sky_mat.ground_bottom_color = Color(0.012, 0.012, 0.035)
	sky_mat.ground_horizon_color = Color(0.05, 0.02, 0.1)
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.34, 0.38, 0.72)
	env.ambient_light_energy = 0.7
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world.environment = env
	add_child(world)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -28, 0)
	sun.light_energy = 1.25
	add_child(sun)

func _build_city() -> void:
	var ground := StaticBody3D.new()
	ground.name = "Ground"
	var ground_mesh := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(300, 300)
	ground_mesh.mesh = plane
	var ground_mat := StandardMaterial3D.new()
	ground_mat.albedo_color = Color(0.025, 0.03, 0.075)
	ground_mat.roughness = 0.92
	ground_mesh.material_override = ground_mat
	ground.add_child(ground_mesh)
	var ground_shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(300, 0.5, 300)
	ground_shape.shape = box
	ground_shape.position.y = -0.25
	ground.add_child(ground_shape)
	add_child(ground)
	var rng := RandomNumberGenerator.new()
	rng.seed = 24061
	for x in range(-CITY_RADIUS, CITY_RADIUS + 1):
		for z in range(-CITY_RADIUS, CITY_RADIUS + 1):
			if abs(x) < 2 and abs(z) < 2:
				continue
			var h := rng.randf_range(9.0, 34.0)
			var w := rng.randf_range(7.0, 11.5)
			var d := rng.randf_range(7.0, 11.5)
			var pos := Vector3(x * BLOCK_SIZE, h / 2.0, z * BLOCK_SIZE)
			_create_building(pos, Vector3(w, h, d), rng)
	# Central plaza and glowing street strips.
	for i in range(-CITY_RADIUS, CITY_RADIUS + 1):
		var strip := MeshInstance3D.new()
		var strip_mesh := BoxMesh.new()
		strip_mesh.size = Vector3(0.13, 0.025, 240)
		strip.mesh = strip_mesh
		var sm := StandardMaterial3D.new()
		sm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		sm.albedo_color = Color(0.0, 0.75, 1.0, 0.8) if i % 2 == 0 else Color(0.85, 0.05, 0.65, 0.75)
		strip.material_override = sm
		strip.position = Vector3(i * BLOCK_SIZE, 0.02, 0)
		add_child(strip)
		var strip2 := MeshInstance3D.new()
		strip2.mesh = strip_mesh
		strip2.material_override = sm
		strip2.rotation.y = PI / 2
		strip2.position = Vector3(0, 0.025, i * BLOCK_SIZE)
		add_child(strip2)

func _create_building(pos: Vector3, size: Vector3, rng: RandomNumberGenerator) -> void:
	var body := StaticBody3D.new()
	body.name = "SwingAnchorBuilding"
	body.position = pos
	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	var mat := StandardMaterial3D.new()
	var hue := rng.randf_range(0.55, 0.82)
	mat.albedo_color = Color.from_hsv(hue, 0.5, rng.randf_range(0.12, 0.28))
	mat.metallic = 0.45
	mat.roughness = 0.38
	mesh_instance.material_override = mat
	body.add_child(mesh_instance)
	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	shape_node.shape = shape
	body.add_child(shape_node)
	# Simple luminous vertical facade accents.
	for side in [-1.0, 1.0]:
		var accent := MeshInstance3D.new()
		var accent_mesh := BoxMesh.new()
		accent_mesh.size = Vector3(0.08, size.y * 0.82, 0.06)
		accent.mesh = accent_mesh
		var accent_mat := StandardMaterial3D.new()
		accent_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		accent_mat.albedo_color = Color(0.0, 0.75, 1.0) if side < 0 else Color(0.95, 0.04, 0.62)
		accent.material_override = accent_mat
		accent.position = Vector3(side * size.x * 0.28, 0, size.z / 2.0 + 0.04)
		body.add_child(accent)
	add_child(body)

func _create_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Hero"
	player.position = Vector3(0, 2.5, 0)
	player.floor_snap_length = 0.4
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.48
	capsule.height = 1.9
	collision.shape = capsule
	collision.position.y = 0.95
	player.add_child(collision)
	var hero_mesh := MeshInstance3D.new()
	var hero_capsule := CapsuleMesh.new()
	hero_capsule.radius = 0.46
	hero_capsule.height = 1.8
	hero_mesh.mesh = hero_capsule
	var hero_mat := StandardMaterial3D.new()
	hero_mat.albedo_color = Color(0.02, 0.12, 0.24)
	hero_mat.metallic = 0.45
	hero_mat.emission_enabled = true
	hero_mat.emission = Color(0.0, 0.6, 1.0)
	hero_mat.emission_energy_multiplier = 0.7
	hero_mesh.material_override = hero_mat
	hero_mesh.position.y = 0.95
	player.add_child(hero_mesh)
	var chest := MeshInstance3D.new()
	var chest_mesh := BoxMesh.new()
	chest_mesh.size = Vector3(0.35, 0.45, 0.12)
	chest.mesh = chest_mesh
	var chest_mat := StandardMaterial3D.new()
	chest_mat.albedo_color = Color(1.0, 0.05, 0.48)
	chest_mat.emission_enabled = true
	chest_mat.emission = Color(0.8, 0.02, 0.35)
	chest_mat.emission_energy_multiplier = 1.5
	chest.material_override = chest_mat
	chest.position = Vector3(0, 1.1, -0.44)
	player.add_child(chest)
	add_child(player)
	camera_pivot = Node3D.new()
	camera_pivot.position = Vector3(0, 1.45, 0)
	player.add_child(camera_pivot)
	camera = Camera3D.new()
	camera.position = Vector3(0, 3.0, 7.5)
	camera.rotation.x = -0.22
	camera.current = true
	camera_pivot.add_child(camera)
	rope = MeshInstance3D.new()
	var rope_mesh := ImmediateMesh.new()
	rope.mesh = rope_mesh
	var rope_mat := StandardMaterial3D.new()
	rope_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rope_mat.albedo_color = Color(0.2, 0.95, 1.0)
	rope_mat.emission_enabled = true
	rope_mat.emission = Color(0.1, 0.8, 1.0)
	rope_mat.emission_energy_multiplier = 2.0
	rope.material_override = rope_mat
	add_child(rope)

func _create_ui() -> void:
	touch_ui = CanvasLayer.new()
	add_child(touch_ui)
	var title := Label.new()
	title.text = "NEON WEB HERO"
	title.position = Vector2(24, 18)
	title.add_theme_font_size_override("font_size", 26)
	title.add_theme_color_override("font_color", Color(0.3, 0.95, 1.0))
	touch_ui.add_child(title)
	status_label = Label.new()
	status_label.text = "Explore the city • Hold WEB to swing"
	status_label.position = Vector2(26, 54)
	status_label.add_theme_font_size_override("font_size", 17)
	status_label.add_theme_color_override("font_color", Color(0.88, 0.9, 1.0))
	touch_ui.add_child(status_label)
	_make_button("▲", Vector2(35, -155), Vector2(72, 62), "move_forward")
	_make_button("▼", Vector2(35, -75), Vector2(72, 62), "move_back")
	_make_button("◀", Vector2(-45, -75), Vector2(72, 62), "move_left")
	_make_button("▶", Vector2(115, -75), Vector2(72, 62), "move_right")
	_make_button("JUMP", Vector2(-185, -100), Vector2(112, 66), "jump")
	_make_button("WEB", Vector2(-185, -180), Vector2(112, 66), "web")

func _make_button(text_value: String, offset: Vector2, button_size: Vector2, action: String) -> void:
	var button := Button.new()
	button.text = text_value
	button.custom_minimum_size = button_size
	button.size = button_size
	button.anchor_left = 1.0 if offset.x < 0 else 0.0
	button.anchor_right = 1.0 if offset.x < 0 else 0.0
	button.anchor_top = 1.0
	button.anchor_bottom = 1.0
	button.position = offset
	button.add_theme_font_size_override("font_size", 20)
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color(0.025, 0.12, 0.23, 0.78)
	normal.border_color = Color(0.0, 0.85, 1.0, 0.95)
	normal.set_border_width_all(2)
	normal.set_corner_radius_all(16)
	button.add_theme_stylebox_override("normal", normal)
	var hover := StyleBoxFlat.new()
	hover.bg_color = Color(0.0, 0.32, 0.48, 0.9)
	hover.border_color = Color(0.5, 0.95, 1.0)
	hover.set_border_width_all(2)
	hover.set_corner_radius_all(16)
	button.add_theme_stylebox_override("pressed", hover)
	button.add_theme_color_override("font_color", Color(0.85, 1.0, 1.0))
	button.button_down.connect(func(): Input.action_press(action))
	button.button_up.connect(func(): Input.action_release(action))
	touch_ui.add_child(button)

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x > get_viewport().get_visible_rect().size.x * 0.38:
				look_drag = true
				last_touch = event.position
		else:
			look_drag = false
	elif event is InputEventScreenDrag and look_drag:
		_rotate_camera(event.relative)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		look_drag = event.pressed
		last_touch = event.position
	elif event is InputEventMouseMotion and look_drag:
		_rotate_camera(event.relative)

func _rotate_camera(delta: Vector2) -> void:
	yaw -= delta.x * 0.004
	pitch = clamp(pitch - delta.y * 0.003, -0.85, 0.35)
	camera_pivot.rotation.y = yaw
	camera.rotation.x = pitch - 0.18

func _physics_process(delta: float) -> void:
	if player == null:
		return
	var input_2d := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var forward := -player.global_transform.basis.z
	var right := player.global_transform.basis.x
	var move_dir := (right * input_2d.x + forward * input_2d.y).normalized()
	var speed := 10.0 if not swinging else 13.5
	if move_dir.length() > 0.01:
		player.velocity.x = move_dir.x * speed
		player.velocity.z = move_dir.z * speed
		player.rotation.y = atan2(-move_dir.x, -move_dir.z)
	else:
		player.velocity.x = move_toward(player.velocity.x, 0.0, 4.0 * delta)
		player.velocity.z = move_toward(player.velocity.z, 0.0, 4.0 * delta)
	if not player.is_on_floor():
		player.velocity.y -= 22.0 * delta
	elif player.velocity.y < 0:
		player.velocity.y = -0.4
	if Input.is_action_just_pressed("jump") and player.is_on_floor():
		player.velocity.y = 9.0
	if Input.is_action_just_pressed("web") and not swinging:
		_start_swing()
	if not Input.is_action_pressed("web") and swinging:
		swinging = false
		_update_rope(false)
	if swinging:
		var pull := anchor - player.global_position
		var distance := pull.length()
		if distance > 0.1:
			player.velocity += pull.normalized() * min(26.0, distance * 1.8) * delta
			# Gentle forward boost makes the rope feel like a swing rather than a winch.
			var swing_forward := -camera_pivot.global_transform.basis.z
			player.velocity += swing_forward * 5.0 * delta
		_update_rope(true)
	player.move_and_slide()
	if player.global_position.y < -10:
		player.global_position = Vector3(0, 4, 0)
		player.velocity = Vector3.ZERO
	if status_label:
		status_label.text = "WEB CONNECTED • release WEB to let go" if swinging else "Drag right side to look • Hold WEB to swing"

func _start_swing() -> void:
	var from := camera.global_position
	var to := from + (-camera.global_transform.basis.z) * 90.0
	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.exclude = [player.get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		# If no wall is directly ahead, target a point above and ahead of the hero.
		anchor = player.global_position + (-camera.global_transform.basis.z * 16.0) + Vector3.UP * 14.0
	else:
		anchor = hit.position + Vector3.UP * 1.5
	swinging = true
	_update_rope(true)

func _update_rope(show_rope: bool) -> void:
	var immediate := rope.mesh as ImmediateMesh
	immediate.clear_surfaces()
	if not show_rope:
		return
	immediate.surface_begin(Mesh.PRIMITIVE_LINES)
	immediate.surface_add_vertex(rope.to_local(player.global_position + Vector3.UP * 1.25))
	immediate.surface_add_vertex(rope.to_local(anchor))
	immediate.surface_end()
